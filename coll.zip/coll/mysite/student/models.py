# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.contrib.auth.models import User
from django.db import models


class Department(models.Model):
    dep_name = models.CharField(max_length=100)


class Student_app(models.Model):
    student_name = models.CharField(max_length=200)
    email_id = models.EmailField(blank=True, null=True)
    date_of_birth = models.DateField(default=True)
    gender = models.CharField(max_length=100)
    tenth_marks = models.FileField(upload_to='media/', null=True, blank=True)
    twevelth_marks = models.ImageField(upload_to='media/', null=True, blank=True)

    def __str__(self):
        return self.student_name


class Student_registration(models.Model):
    student_name = models.OneToOneField(Student_app, unique=True, on_delete=models.CASCADE)
    father_name = models.CharField(max_length=200)
    mother_name = models.CharField(max_length=200)
    place = models.CharField(max_length=500)
    age = models.IntegerField()
    photo_upload = models.ImageField(upload_to='media/', null=True, blank=True)
    user = models.OneToOneField(User)
    department = models.ForeignKey(Department)
