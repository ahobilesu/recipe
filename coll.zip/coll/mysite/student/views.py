# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.shortcuts import render, HttpResponseRedirect
from .forms import StudentApplicationForm

# Create your views here.


def home(request):
    return render(request, "home.html")


def student_application(request):
    if request.method == "GET":
        stu = StudentApplicationForm()
        return render(request, "stu_application.html", {"student": stu})
    ob = StudentApplicationForm(request.POST, request.FILES)
    if ob.is_valid():
        ob.save()
        return HttpResponseRedirect("/")
    else:
        return render(request, "stu_application.html", {"errors": ob.errors})



