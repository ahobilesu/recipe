from django.forms import ModelForm
from .models import Student_app


class StudentApplicationForm(ModelForm):
    class Meta:
        model = Student_app
        fields = ["student_name", "email_id", "date_of_birth", "gender", "tenth_marks", "twevelth_marks"]